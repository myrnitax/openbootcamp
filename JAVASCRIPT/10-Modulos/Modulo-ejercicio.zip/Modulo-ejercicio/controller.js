export function suma(a, b) {
  return a + b;
}
export function multiplicar(a, b) {
  return a * b;
}
