const edad = prompt("¿Cual es tu edad");
