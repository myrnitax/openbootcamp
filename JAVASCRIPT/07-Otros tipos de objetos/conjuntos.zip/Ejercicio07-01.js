const familia = ["Manuel", "Vicky", "Angie", "Mario", "Myrna"];
const familia2 = new Set(familia);
console.log(familia2);

familia2.add("Myrna");
console.log(familia2);
familia2.add("Javascript");
console.log(familia2);
