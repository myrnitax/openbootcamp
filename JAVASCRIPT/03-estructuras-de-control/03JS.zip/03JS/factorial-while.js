let fact = 10;
let i = 1;

while (i < 10) {
  fact *= i;
  i++;
}
console.log(fact);
