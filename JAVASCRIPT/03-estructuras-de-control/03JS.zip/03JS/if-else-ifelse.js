// If else + if else
//ejemplo1
let nota = 200;

if (nota === 5) {
  console.log("Enhorabuena, has obtenido un sobresalir");
} else if (nota === 4) {
  console.log("Buen trabajo, pero podrias haberlo hecho mejor");
} else if (nota === 3) {
  console.log("Haz obtenido un suficiente");
} else if (nota === 2) {
  console.log("No haz aprobado por poco");
} else if (nota === 1) {
  console.log("No haz estudiado nada, trabaja un poquito mas para la proxima");
} else {
  console.log("Error, introduce una nota entre el 1 y el 5");
}
//ejemplo2
let nota2 = 3;

if (nota2 === 5) {
  console.log("Enhorabuena, has obtenido un sobresalir");
} else if (nota2 === 4) {
  console.log("Buen trabajo, pero podrias haberlo hecho mejor");
} else if (nota2 === 3) {
  console.log("Haz obtenido un suficiente");
} else if (nota2 === 2) {
  console.log("No haz aprobado por poco");
} else if (nota2 === 1) {
  console.log("No haz estudiado nada, trabaja un poquito mas para la proxima");
} else {
  console.log("Error, introduce una nota entre el 1 y el 5");
}
