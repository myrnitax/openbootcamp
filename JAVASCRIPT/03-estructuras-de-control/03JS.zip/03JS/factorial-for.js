// factorial for
let factorial = 1;

for (let i = 1; i <= 10; i++) {
  factorial = factorial * i;
}
console.log(factorial);
