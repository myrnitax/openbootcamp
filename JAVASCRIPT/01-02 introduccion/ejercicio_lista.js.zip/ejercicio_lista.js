const lista = [
  "Myrna",
  35,
  true,
  new Date(1987, 10, 23),
  {
    nombre: "Levantando la cortina",
    autor: "Rodolfo Benavides",
    fecha: new Date(1977, 0, 01),
    URL: "https://www.amazon.com.mx/LEVANTANDO-CORTINA-RODOLFO-BENAVIDES-BLANDA/dp/9681321774#:~:text=Aceptar-,LEVANTANDO%20LA%20CORTINA%20%2D%20RODOLFO%20BENAVIDES%20%5BPASTA%20BLANDA%5D,Pasta%20blanda%20%E2%80%93%201%20enero%201991",
  },
];
console.log(lista);
