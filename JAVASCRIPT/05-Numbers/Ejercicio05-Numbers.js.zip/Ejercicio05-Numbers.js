let alt_cm = 159;
let alt_mt = 1.59;
let peso_kg = 69.5;

let alt_round = Math.ceil(alt_mt);
let peso_round = Math.floor(peso_kg);
let text = "el máximo valor que se puede obtener en Javascript + 1";
console.log(alt_round);
console.log(peso_round);

const igual_al_máximo_valor_js = Number.MAX_VALUE + 1 === Number.MAX_VALUE;
console.log(igual_al_máximo_valor_js);
